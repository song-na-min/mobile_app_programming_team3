package com.example.viewpagerswipe

import android.content.DialogInterface
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.TabHost
import android.widget.TabHost.TabSpec
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    var btnOk01: ImageButton? = null
    var btnOk02: ImageButton? = null
    var btnOk03: ImageButton? = null
    var btnOk04: ImageButton? = null
    var btnOk05: ImageButton? = null
    var btnOk06: ImageButton? = null
    var btnOk07: ImageButton? = null
    var posterTitle: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        btnOk01 = findViewById<View>(R.id.btnOk01) as ImageButton
        btnOk01!!.setOnClickListener { v ->
            posterTitle = "Face To Face"
            Toast.makeText(this@MainActivity, posterTitle, Toast.LENGTH_SHORT).show()
            movieSelect(v)
        }
        btnOk02 = findViewById<View>(R.id.btnOk02) as ImageButton
        btnOk02!!.setOnClickListener { v ->
            posterTitle = "세시 공간"
            Toast.makeText(this@MainActivity, posterTitle, Toast.LENGTH_SHORT).show()
            movieSelect(v)
        }
        btnOk03 = findViewById<View>(R.id.btnOk03) as ImageButton
        btnOk03!!.setOnClickListener { v ->
            posterTitle = "Land Escape"
            Toast.makeText(this@MainActivity, posterTitle, Toast.LENGTH_SHORT).show()
            movieSelect(v)
        }
            btnOk04 = findViewById<View>(R.id.btnOk04) as ImageButton
            btnOk04!!.setOnClickListener { v ->
                posterTitle = "NAJBO KONEC LEP"
                Toast.makeText(this@MainActivity, posterTitle, Toast.LENGTH_SHORT).show()
                movieSelect(v)
            }
                btnOk05 = findViewById<View>(R.id.btnOk05) as ImageButton
                btnOk05!!.setOnClickListener { v ->
                    posterTitle = "세상의 그림자"
                    Toast.makeText(this@MainActivity, posterTitle, Toast.LENGTH_SHORT).show()
                    movieSelect(v)
                }
                    btnOk06 = findViewById<View>(R.id.btnOk06) as ImageButton
                    btnOk06!!.setOnClickListener { v ->
                        posterTitle = "FAKE"
                        Toast.makeText(this@MainActivity,posterTitle, Toast.LENGTH_SHORT).show()
                        movieSelect(v)
                    }
        btnOk07 = findViewById<View>(R.id.btnOk07) as ImageButton
        btnOk07!!.setOnClickListener { v ->
            posterTitle = "세상속으로"
            Toast.makeText(this@MainActivity,posterTitle, Toast.LENGTH_SHORT).show()
            movieSelect(v)
        }

    }
}

fun movieSelect(v: View?) {
    val message = AlertDialog.Builder(this)
    message.setMessage(posterTitle + "을 예매하시느게 맞나요?")
    message.setPositiveButton(
        posterTitle + "가 예매하겠습니다."
    ) { dialog, which ->
        Toast.makeText(
            this@MainActivity,
            posterTitle + "을 예매되었습니다.",
            Toast.LENGTH_SHORT
        ).show()
    }
    message.setNegativeButton(
        "아니요"
    ) { dialog, which ->
        Toast.makeText(this@MainActivity, "취소되었습니다.", Toast.LENGTH_SHORT).show()
    }
    val alert = message.create()
    alert.show()
}
}


