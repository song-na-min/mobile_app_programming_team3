package com.example.fairstudy.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.fairstudy.databinding.ItemFairBinding
import com.example.fairstudy.model.Fair

//view binding
class FairAdapter(private val itemClickListener: (Fair)->Unit): ListAdapter<Fair, FairAdapter.FairItemViewHolder>(diffUtil) {
    //view binding(item_fair.xml)
    inner class FairItemViewHolder(private val binding: ItemFairBinding): RecyclerView.ViewHolder(binding.root){
        fun bind(fairModel: Fair){
            binding.titleTextView.text=fairModel.title
            binding.descriptionTextView.text=fairModel.description

            binding.root.setOnClickListener{
                itemClickListener(fairModel)
            }

            // Glide 사용 하기
            Glide
                .with(binding.coverImageView.context)
                .load(fairModel.referenceIdentifier)
                .into(binding.coverImageView)
        }
    }
    // create if not exit
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FairItemViewHolder {
        return FairItemViewHolder(ItemFairBinding.inflate(LayoutInflater.from(parent.context),parent,false))
    }

    override fun onBindViewHolder(holder: FairItemViewHolder, position: Int) {
        holder.bind(currentList[position])
    }
    companion object{
        val diffUtil = object: DiffUtil.ItemCallback<Fair>(){
            override fun areItemsTheSame(oldItem: Fair, newItem: Fair): Boolean {
                return oldItem == newItem
            }

            override fun areContentsTheSame(oldItem: Fair, newItem: Fair): Boolean {
                return oldItem.id == newItem.id
            }
        }
    }
}