package com.example.fairstudy.model


import android.content.ClipData
import android.os.Parcel
import android.os.Parcelable
import com.google.gson.annotations.SerializedName



data class Fair(
    @SerializedName("rn") val id: Long = 0,
    @SerializedName("title") val title: String? = "", //제목
    @SerializedName("referenceIdentifier") val referenceIdentifier: String? = "", //썸네일 이미지
    @SerializedName("description") val description: String? = "", //설명
    @SerializedName("venue") val venue: String? = "",
    @SerializedName("time") val time: String? = "",
    @SerializedName("charge") val charge: String? = "" //요금

): Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readLong(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString()
    ) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeLong(id)
        parcel.writeString(title)
        parcel.writeString(referenceIdentifier)
        parcel.writeString(description)
        parcel.writeString(venue)
        parcel.writeString(time)
        parcel.writeString(charge)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Fair> {
        override fun createFromParcel(parcel: Parcel): Fair {
            return Fair(parcel)
        }

        override fun newArray(size: Int): Array<Fair?> {
            return arrayOfNulls(size)
        }
    }
}
