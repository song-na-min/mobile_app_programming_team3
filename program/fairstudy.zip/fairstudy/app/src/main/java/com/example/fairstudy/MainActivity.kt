package com.example.fairstudy

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fairstudy.adapter.FairAdapter
import com.example.fairstudy.api.FairService
import com.example.fairstudy.databinding.ActivityMainBinding
import com.example.fairstudy.model.AllFairDto
import com.example.fairstudy.model.SearchFairDto

import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit

import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {
    private lateinit var fairService: FairService
    private lateinit var fairRecyclerViewAdapter: FairAdapter
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initFairRecyclerView()
        //initHistoryRecyclerView()
        initSearchEditText()

        initFairService()
        fairServiceLoadAllFair()
    }

    private fun fairServiceLoadAllFair() {
        fairService.getAllFair(getString(R.string.fairAPIKey))
            .enqueue(object : Callback<AllFairDto>{
                // response
                override fun onResponse(
                    call:Call<AllFairDto>,
                    response: Response<AllFairDto>
                ){
                    // success response
                    if(response.isSuccessful.not()){
                        Log.e(M_TAG,"not success")
                        return
                    }
                    // only if body is filled
                    response.body()?.let {
                        Log.d(M_TAG, it.toString())

                        it.fairs.forEach { fair ->
                            Log.d(M_TAG, fair.toString())
                        }

                        // renew to new list
                        fairRecyclerViewAdapter.submitList(it.fairs)
                    }
                }
                //fail
                override fun onFailure(call:Call<AllFairDto>,t:Throwable){
                    Log.e(M_TAG, t.toString())
                }
            })
    }

    private fun initFairService(){
        val retrofit = Retrofit.Builder()
            .baseUrl("http://api.kcisa.kr/")
            .client(OkHttpClient())
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        fairService = retrofit.create(FairService::class.java)
    }

    private fun initFairRecyclerView() {//
        fairRecyclerViewAdapter = FairAdapter(itemClickListener = {
            val intent = Intent(this, DetailActivity::class.java)

            intent.putExtra("fairModel", it)
            startActivity(intent)
        })
        binding.fairRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.fairRecyclerView.adapter = fairRecyclerViewAdapter
    }

//    private fun initBookRecyclerView() {
//        bookRecyclerViewAdapter = BookAdapter(itemClickedListener = {
//            val intent = Intent(this, DetailActivity::class.java)
//
//            // 직렬화 해서 넘길 것.
//            intent.putExtra("bookModel", it)
//            startActivity(intent)
//        })
//
//        binding.bookRecyclerView.layoutManager = LinearLayoutManager(this)
//        binding.bookRecyclerView.adapter = bookRecyclerViewAdapter
//    }


    fun fairServiceSearchFair(keyword: String) {

        fairService.getFairName(getString(R.string.fairAPIKey), keyword)
            .enqueue(object : Callback<SearchFairDto> {
                // 성공.

                override fun onResponse(
                    call: Call<SearchFairDto>,
                    response: Response<SearchFairDto>
                ) {
                    //hideHistoryView()
                    //saveSearchKeyword(keyword)

                    if (response.isSuccessful.not()) {
                        return
                    }

                    fairRecyclerViewAdapter.submitList(response.body()?.fairs.orEmpty()) // 새 리스트로 갱신
                }

                // 실패.
                override fun onFailure(call: Call<SearchFairDto>, t: Throwable) {
                    //hideHistoryView()
                    Log.e(M_TAG, t.toString())
                }
            })
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initSearchEditText() {
        binding.searchEditText.setOnKeyListener { v, keyCode, event ->
            // 키보드 입력시 발생

            // 엔터 눌렀을 경우 (눌렀거나, 뗏을 때 -> 눌렀을 때 발생하도록.)
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.action == MotionEvent.ACTION_DOWN) {
                fairServiceSearchFair(binding.searchEditText.text.toString())
                return@setOnKeyListener true// 처리 되었음.
            }
            return@setOnKeyListener false // 처리 안됬음 을 나타냄.
        }

        binding.searchEditText.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                //showHistoryView()
            }
            return@setOnTouchListener false
        }
    }

    companion object {
        private const val M_TAG = "MainActivity"
    }


}
