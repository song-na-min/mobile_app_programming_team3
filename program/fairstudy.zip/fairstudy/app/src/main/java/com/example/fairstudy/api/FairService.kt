package com.example.fairstudy.api

import com.example.fairstudy.model.AllFairDto
import com.example.fairstudy.model.SearchFairDto
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface FairService {
    // show all fair
    @GET("openapi/service/rest/convergence/conver6?output=json/")
    fun getAllFair(
        @Query("serviceKey") apiKey:String
        //@Query("title") title:String
    ): Call<AllFairDto>

    // search fair by name
    @GET("openapi/service/rest/convergence/conver6?output=json/")
    fun getFairName(
        @Query("serviceKey") apiKey: String,
        @Query("title") title:String,
        //@Query("subjectKeyword") subjectKeyword:String,
//        @Query("description") description:String,
//        @Query("charge") charge:String

    ): Call<SearchFairDto>

}
