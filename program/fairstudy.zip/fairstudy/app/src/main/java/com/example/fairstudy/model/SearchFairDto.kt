package com.example.fairstudy.model

import com.google.gson.annotations.SerializedName

data class SearchFairDto(
    @SerializedName("title") val title:String,
    @SerializedName("item") val fairs: List<Fair>,
)