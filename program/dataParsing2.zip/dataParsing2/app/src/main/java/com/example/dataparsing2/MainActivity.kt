package com.example.dataparsing2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import org.w3c.dom.Element
import java.net.URL
import javax.xml.parsers.DocumentBuilderFactory

class MainActivity : AppCompatActivity() {
    lateinit var textView : TextView
    lateinit var button : Button
    lateinit var imgView : ImageView
    var pageNo : Int = 1 //pageNo:1~
    var rowNum : Int = 10 //한 페이지에 불러올 rows 수

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textView = findViewById<TextView>(R.id.textView)
        button = findViewById<Button>(R.id.btn)
        textView.text = ""

        // 버튼을 누르면 쓰레드 가동
        button.setOnClickListener {
            var thread = NetworkThread()
            thread.start()
        }
    }

    inner class NetworkThread: Thread(){
        override fun run() {
            try {
                // 접속할 페이지의 주소
                var site = "http://api.kcisa.kr/openapi/service/rest/convergence/conver6?serviceKey="+resources.getString(R.string.apiKey)
//                +"&pageNo="+pageNo+"&numOfRows="+rowNum
                var url = URL(site)
                var conn = url.openConnection()
                var input = conn.getInputStream()

                var factory = DocumentBuilderFactory.newInstance()
                var builder = factory.newDocumentBuilder()
                // doc: xml문서를 모두 읽어와서 분석을 끝냄
                var doc = builder.parse(input)

                // root: xml 문서의 모든 데이터들을 갖고 있는 객체
                var root = doc.documentElement

                // xml 문서에서 태그 이름이 item인 태그들이 item_node_list에 리스트로 담김
                var item_node_list = root.getElementsByTagName("item")

                // item_node_list에 들어있는 태그 객체 수만큼 반복함
                for(i in 0 until item_node_list.length){
                    // i번째 태그 객체를 item_element에 넣음
                    var item_element = item_node_list.item(i) as Element

                    // item태그 객체에서 원하는 데이터를 태그이름을 이용해서 데이터를 가져옴
                    // xml 문서는 태그 이름으로 데이터를 가져오면 무조건 리스트로 나옴

                    var creator_list = item_element.getElementsByTagName("creator")
                    var description_list = item_element.getElementsByTagName("description")
                    var period_list = item_element.getElementsByTagName("period")
                    var referenceIdentifier_list = item_element.getElementsByTagName("referenceIdentifier")
                    var time_list = item_element.getElementsByTagName("time")
                    var title_list = item_element.getElementsByTagName("title")
                    var venue_list = item_element.getElementsByTagName("venue")


                    var creator_node = creator_list.item(0) as Element
                    var description_node = description_list.item(0) as Element
                    var period_node = period_list.item(0) as Element
                    var referenceIdentifier_node = referenceIdentifier_list.item(0) as Element
                    var time_node = time_list.item(0) as Element
                    var title_node = title_list.item(0) as Element
                    var venue_node = venue_list.item(0) as Element

                    // 태그 사이에 있는 문자열을 가지고 오는 작업
                    var creator = creator_node.textContent
                    var description = description_node.textContent
                    var period = period_node.textContent
                    var referenceIdentifier = referenceIdentifier_node.textContent
                    var time = time_node.textContent
                    var title = title_node.textContent
                    var venue = venue_node.textContent

                    //Glide.with(NetworkThread.this).load(referenceIdentifier).into(imgView); //?

                    // Ui에 데이터를 출력해주는 부분
                    runOnUiThread {
                        textView.append("제목 : ${title}\n")
                        textView.append("공급자: ${creator}\n")
                        textView.append("장소 : ${venue}\n")
                        textView.append("기간 : ${period}\n\n")
                        textView.append("시간 : ${time}\n\n")
                        textView.append("설명: ${description}\n\n")

                    }
                }
            }catch (e: Exception){
                e.printStackTrace()
            }
        }
    }
}