package com.cookandroid.google_login_1116_2nd.navigation

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.cookandroid.google_login_1116_2nd.R
import com.cookandroid.google_login_1116_2nd.navigation.model.ContentDTO
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class CommentActivity : AppCompatActivity() {
    var contentUid : String?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_comment)
        contentUid = intent.getStringExtra("contentUid")
        var imageUri = intent.getStringExtra("imageUri")
        var Exhibition_name = intent.getStringExtra("Exhibition_name")
        var explain = intent.getStringExtra("explain")

        var detailviewitemimageview_content=findViewById<ImageView>(R.id.detailviewitem_imageview_content)
        var detailviewitem_explain_textview=findViewById<TextView>(R.id.detailviewitem_explain_textview)
        var Exhibition_name_textview=findViewById<TextView>(R.id.Exhibition_name_textview)

        detailviewitem_explain_textview.text=explain
        Glide.with(this).load(imageUri).into(detailviewitemimageview_content)
        Exhibition_name_textview.text=Exhibition_name

        var comment_recyclerview=findViewById<RecyclerView>(R.id.comment_recyclerview)

        comment_recyclerview.adapter = CommentRecyclerViewAdapter()
        comment_recyclerview.layoutManager = LinearLayoutManager(this)

        var comment_btn_send= findViewById<Button>(R.id.comment_btn_send)
        var comment_edit_message= findViewById<EditText>(R.id.comment_edit_message)
        comment_btn_send.setOnClickListener {
            var comment=ContentDTO.Comment()
            comment.userId = FirebaseAuth.getInstance().currentUser?.email
            comment.uid = FirebaseAuth.getInstance().currentUser?.uid
            comment.comment= comment_edit_message.text.toString()
            comment.timestamp=System.currentTimeMillis()

            FirebaseFirestore.getInstance().collection("images").document(contentUid!!).collection("comments").document().set(comment)

            comment_edit_message.setText("")
        }

    }
    inner class CommentRecyclerViewAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        val comments: ArrayList<ContentDTO.Comment> = arrayListOf()

        init {

            FirebaseFirestore
                .getInstance()
                .collection("images")
                .document(contentUid!!)
                .collection("comments").orderBy("timestamp")
                .addSnapshotListener { querySnapshot, firebaseFirestoreException ->
                    comments.clear()
                    if (querySnapshot == null) return@addSnapshotListener
                    for (snapshot in querySnapshot?.documents!!) {
                        comments.add(snapshot.toObject(ContentDTO.Comment::class.java)!!)
                    }
                    notifyDataSetChanged()

                }

        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_comment, parent, false)
            return CustomViewHolder(view)
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

            var view = holder.itemView
            var commentviewitem_imageview_profile=view.findViewById<ImageView>(R.id.commentviewitem_imageview_profile)
            var commentviewitem_textview_profile=view.findViewById<TextView>(R.id.commentviewitem_textview_profile)
            var commentviewitem_textview_comment=view.findViewById<TextView>(R.id.commentviewitem_textview_comment)
            // Profile Image
            FirebaseFirestore.getInstance()
                .collection("profileImages")
                .document(comments[position].uid!!)
                .addSnapshotListener { documentSnapshot, firebaseFirestoreException ->
                    if (documentSnapshot?.data != null) {

                        val url = documentSnapshot?.data!!["image"]
                        Glide.with(holder.itemView.context)
                            .load(url)
                            .apply(RequestOptions().circleCrop()).into(commentviewitem_imageview_profile)
                    }
                }

            commentviewitem_textview_profile.text = comments[position].userId
            commentviewitem_textview_comment.text = comments[position].comment
        }

        override fun getItemCount(): Int {

            return comments.size
        }

        private inner class CustomViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
    }
}