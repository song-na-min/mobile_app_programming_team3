package com.cookandroid.google_login_1116_2nd

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.widget.LinearLayoutCompat
import com.google.android.gms.maps.CameraUpdateFactory

import com.google.android.gms.maps.model.MarkerOptions

import com.google.android.gms.maps.model.LatLng

import com.google.android.gms.maps.GoogleMap

import androidx.lifecycle.Transformations.map
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.cookandroid.google_login_1116_2nd.navigation.model.ContentDTO
import com.cookandroid.google_login_1116_2nd.navigation.model.LocationDTO
import com.cookandroid.google_login_1116_2nd.navigation.model.UserDTO

import com.google.android.gms.maps.SupportMapFragment

import com.google.android.gms.maps.OnMapReadyCallback
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class GoogleMap : AppCompatActivity(), OnMapReadyCallback {
    private var mMap: GoogleMap? = null
    var firestore: FirebaseFirestore? = null
    var uid: String? = null
    var auth: FirebaseAuth? = null
    var currentUserUid: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_google_map)

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment!!.getMapAsync(this)
        //uid = arguments?.getString("destinationUid")
        var intent = getIntent()
        var uid=intent.getStringExtra("uid")
        var contentDTOs: ArrayList<ContentDTO> = arrayListOf()
        var userDTOs : ArrayList<UserDTO.Location> = arrayListOf()
        var locationDTOs : ArrayList<LocationDTO> = arrayListOf()
        firestore?.collection("userlocation")?.document(uid!!)?.collection("Location")?.addSnapshotListener{
                querySnapshot,firebaseFirestore->
            if(querySnapshot==null) return@addSnapshotListener
            for(snapshot in querySnapshot.documents){
                userDTOs.add(snapshot.toObject(UserDTO.Location::class.java)!!)
            }
        }
    }
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        val SEOUL = LatLng(39.0, 126.97)
        val markerOptions = MarkerOptions()
        markerOptions.position(SEOUL)
        markerOptions.title("서울")
        markerOptions.snippet("한국의 수도")
        mMap!!.addMarker(markerOptions)

        // 기존에 사용하던 다음 2줄은 문제가 있습니다.
        // CameraUpdateFactory.zoomTo가 오동작하네요.
        //mMap.moveCamera(CameraUpdateFactory.newLatLng(SEOUL));
        //mMap.animateCamera(CameraUpdateFactory.zoomTo(10));
        mMap!!.moveCamera(CameraUpdateFactory.newLatLngZoom(SEOUL, 10f))
    }

}