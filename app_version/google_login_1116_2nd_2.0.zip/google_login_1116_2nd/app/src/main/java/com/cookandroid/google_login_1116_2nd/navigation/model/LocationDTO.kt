package com.cookandroid.google_login_1116_2nd.navigation.model

data class LocationDTO (
    var lat : Float = 0.0F,
    var long : Float = 0.0F,
    var location_name :String ?=null,
    var location_id : Int =0
    )