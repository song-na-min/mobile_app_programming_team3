package com.cookandroid.google_login_1116_2nd.navigation.model

data class UserDTO (
    var uid:String?=null,
    var userId:String?=null,
) {
    data class Location(//댓글 데이터 관리
        var location_name : String?=null,
        var timestamp:Long?=null,//언제
        var location_lat : Float,
        var location_long : Float
    )
}
