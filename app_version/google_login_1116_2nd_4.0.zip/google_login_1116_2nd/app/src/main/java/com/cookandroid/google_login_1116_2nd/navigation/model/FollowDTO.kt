package com.cookandroid.google_login_1116_2nd.navigation.model

data class FollowDTO (
    var followerCount : Int=0,
    var followers : MutableMap<String,Boolean> =HashMap(),

    var followingCount : Int=0,
    var followings : MutableMap<String,Boolean> =HashMap()
)