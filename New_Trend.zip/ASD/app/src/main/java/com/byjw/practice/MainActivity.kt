package com.byjw.practice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val list = this.game_list
        
        // 더미 데이터
        val items = mutableListOf<GameData>().apply {
            this.add(GameData("Face To Face", "11.21 ~ 11.25",R.drawable.image1,"경북대학교", 5.0f))
            this.add(GameData("세시 공간", "11.23 ~ 12.01", R.drawable.image3,"○○대학교", 4.5f))
            this.add(GameData("Land Escape", "11.25 ~ 12.20", R.drawable.image2,"호암미술관", 5.0f))
            this.add(GameData("NAJBO KONEC LEP", "12.01 ~ 12.25", R.drawable.image18,"○○미술관", 4.0f))
            this.add(GameData("세상의 그림자", "12.05 ~ 12.31",R.drawable.image20,"○○전시회", 3.0f))
            this.add(GameData("FAKE", "12.10 ~ 12.31", R.drawable.image21,"경북대학교", 4.5f))
            this.add(GameData("세상속으로", "12.15 ~ 12.31",R.drawable.image22,"경북대학교" , 3.0f))
        }

        list.adapter = GameAdapter(items)

    }
}