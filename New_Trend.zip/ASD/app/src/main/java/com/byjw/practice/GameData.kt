package com.byjw.practice

data class GameData(
    val title: String,
    val genre: String,
    val thumbnail: Int,
    val genre2: String,
    val rating: Float



)