package com.example.viewpagerswipe

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import kotlinx.android.synthetic.main.activity_main2.*

class MainActivity : AppCompatActivity() {
    private var vpAdapter: FragmentStatePagerAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        vpAdapter = CustomPagerAdapter(supportFragmentManager)
        viewpager.adapter = vpAdapter


    }

    class CustomPagerAdapter(fm: FragmentManager): FragmentStatePagerAdapter(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {
        private val PAGENUMBER = 7

        override fun getCount(): Int {
            return PAGENUMBER
        }

        override fun getItem(position: Int): Fragment {
            return when (position) {
                0 -> TestFragment.newInstance(R.drawable.image4, "test 00")
                1 -> TestFragment.newInstance(R.drawable.image8, "test 01")
                2 -> TestFragment.newInstance(R.drawable.image9, "test 02")
                3 -> TestFragment.newInstance(R.drawable.image10, "test 03")
                4 -> TestFragment.newInstance(R.drawable.image11, "test 04")
                5 -> TestFragment.newInstance(R.drawable.image12, "test 05")
                else -> TestFragment.newInstance(R.drawable.image13, "test 06")
            }
        }
    }
}